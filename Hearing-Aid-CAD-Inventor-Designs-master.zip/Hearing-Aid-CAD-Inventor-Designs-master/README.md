# Hearing-Aid-CAD/Inventor-Designs
The CAD and Inventor designs for the hearing aid project.
